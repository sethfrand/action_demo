import numpy as np

def greet(name: str) -> str:
    return f"Hello, {name}!"
